<?php
include "../connect.php";

try {
    $con->beginTransaction();

    if (isset($_POST['studentID']) && isset($_POST['classCode'])) {
        $studentID = filterRequest("studentID");
        $classCode = filterRequest("classCode");

        $userClassStmt = $con->prepare("SELECT * FROM viewclass WHERE linkCode = :classCode");
        $userClassStmt->bindParam(':classCode', $classCode, PDO::PARAM_STR);
        $userClassStmt->execute();
        $countClassData = $userClassStmt->rowCount();
        $classData = $userClassStmt->fetch(PDO::FETCH_ASSOC);

        $teacherClassID = $classData['teacherClassID'];

        if ($countClassData > 0) {
            $userRequestStmt = $con->prepare("SELECT * FROM request WHERE studentID = :studentID AND teacherClassID = :teacherClassID");
            $userRequestStmt->bindParam(':studentID', $studentID, PDO::PARAM_STR);
            $userRequestStmt->bindParam(':teacherClassID', $teacherClassID, PDO::PARAM_STR);
            $userRequestStmt->execute();
            $countRequestData = $userRequestStmt->rowCount();

            if ($countRequestData > 0) {
                printFailure("Request already submitted. Please wait for teacher approval.");
            } else {

                $userClassroomStmt = $con->prepare("SELECT * FROM classroom  WHERE studentID = :studentID AND teacherClassID = :teacherClassID");
                $userClassroomStmt->bindParam(':studentID', $studentID, PDO::PARAM_STR);
                $userClassroomStmt->bindParam(':teacherClassID', $teacherClassID, PDO::PARAM_STR);
                $userClassroomStmt->execute();
                $countClassroomData = $userClassroomStmt->rowCount();

                if ($countClassroomData > 0) {
                    printFailure("You are already enrolled in this class.");
                }else{
                    $data = array(
                        "studentID" => $studentID,
                        "teacherClassID" => $teacherClassID,
                    );
    
                    insertData("request", $data);
                }  
            }
        } else {
            printFailure("Class Code doesn't exist");
        }
    } else {
        printFailure("Please send parameters");
    }

    $con->commit();
} catch (PDOException $e) {
    $con->rollBack();
    printFailure("Something went wrong. Please try again later");
}
