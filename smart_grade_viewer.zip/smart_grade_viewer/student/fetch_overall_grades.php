<?php
include "../connect.php";

if(isset($_POST['studentID'])){
    $studentID = filterRequest("studentID");
    $isArchived = 0;
    $allData = array();
    $allData['status'] = "success";

    $sql = "SELECT *, YEAR(date_created) AS year, semester FROM viewstudentclass WHERE studentID = :studentID AND grade IS NOT NULL ORDER BY year, semester";
    $stmt = $con->prepare($sql);
    $stmt->bindParam(':studentID', $studentID);
    $stmt->execute();

    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $organizedData = array();
    foreach ($classes as $class) {
        $year = $class['year'];
        $sem = $class['semester'];

        $classInfo = array(
            'isArchived' => $class['isArchived'],
            'studentFirstName' => $class['studentFirstName'],
            'studentLastName' => $class['studentLastName'],
            'studentEmailAddress' => $class['studentEmailAddress'],
            'teacherProfile' => $class['teacherProfile'],
            'classroomID' => $class['classroomID'],
            'teacherClassID' => $class['teacherClassID'],
            'grade' => $class['grade'],
            'studentMiddleName' => $class['studentMiddleName'],
            'firstName' => $class['firstName'],
            'lastName' => $class['lastName'],
            'studentProfile' => $class['studentProfile'],
            'teacherID' => $class['teacherID'],
            'classID' => $class['classID'],
            'name' => $class['name'],
            'code' => $class['code'],
            'linkCode' => $class['linkCode'],
            'block' => $class['block'],
            'semester' => $class['semester'],
            'color' => $class['color'],
            'date_created' => $class['date_created']
        );

        $organizedData[$year][$sem]['year'] = $year;
        $organizedData[$year][$sem]['semester'] = $sem;
        $organizedData[$year][$sem]['class'][] = $classInfo;
    }

    $flattenedData = array();
    foreach ($organizedData as $year => $yearData) {
        foreach ($yearData as $sem => $semData) {
            $flattenedData[] = $semData;
        }
    }

    $allData['viewstudentclass'] = $flattenedData;

    echo json_encode($allData);
} else {
    printFailure("Please send parameters");
}
?>
