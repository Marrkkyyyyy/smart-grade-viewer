<?php
include "../connect.php";

try {
    $con->beginTransaction();

    if (isset($_POST['studentID']) && isset($_POST['teacherClassID']) && isset($_POST['evaluation']) && isset($_POST['comment'])) {
        date_default_timezone_set('Asia/Manila');     
        $currentTime = date('Y-m-d H:i:s');
        $studentID = filterRequest("studentID");
        $teacherClassID = filterRequest("teacherClassID");
        $evaluation = $_POST['evaluation'];
        $comment = filterRequest("comment");
        
        $data = array(
            "studentID" => $studentID,
            "teacherClassID" => $teacherClassID,
            "evaluation" => $evaluation,
            "comment" => $comment,
            "dateCreated" => $currentTime,
        );

        insertData("evaluation", $data, null);
        
        $con->commit();
        
        printSuccess();
    } else {
        printFailure("Please send parameters");
    }

} catch (PDOException $e) {
    $con->rollBack();
    printFailure("Something went wrong. Please try again later");
}

?>
