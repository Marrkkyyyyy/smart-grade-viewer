<?php
include "../connect.php";

try {
    $con->beginTransaction();

    if (isset($_POST['studentID']) && isset($_POST['firstName']) && isset($_POST['lastName']) && isset($_POST['emailAddress'])) {
        $studentID = filterRequest("studentID");
        $firstName = filterRequest("firstName");
        $lastName = filterRequest("lastName");
        $emailAddress = filterRequest("emailAddress");
        $imageURL = null;

        $stmt = $con->prepare("SELECT emailAddress FROM (
            SELECT emailAddress FROM student WHERE studentID != :studentID
            UNION ALL
            SELECT emailAddress FROM admin
            UNION ALL
            SELECT emailAddress FROM teacher
            ) AS all_emails
            WHERE emailAddress = :email");
        $stmt->bindParam(':email', $emailAddress, PDO::PARAM_STR);
        $stmt->bindParam(':studentID', $studentID, PDO::PARAM_INT);
        $stmt->execute();
        $count = $stmt->rowCount();


        if ($count > 0) {
            printFailure("Email address is already taken. Please try another.");
        } else {

            if (isset($_FILES['image'])) {
                $image = $_FILES['image'];

                $user_folder = "../auth/user_profile/";
                $original_file_name1 = basename($image['name']);
                $original_file_name = preg_replace('/[\s,]+/', '_', $original_file_name1);
                $target_file = $user_folder . $original_file_name;

                if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    throw new Exception('Failed to upload image: ' . $_FILES['image']['error']);
                } else {
                    $imageURL = $original_file_name;
                }
            }

            $data = array(
                "firstName" => $firstName,
                "lastName" => $lastName,
                "emailAddress" => $emailAddress,
                "profile" => $imageURL
            );

            $res = updateData("student", $data, "studentID = $studentID", null);
            if($res){
                printSuccess();
            }else{
                printFailure("Something went wrong. Please try again later.");
            }
        }
    } else {
        printFailure("Please send parameters");
    }

    $con->commit();
} catch (PDOException $e) {
    $con->rollBack();
    printFailure("Something went wrong. Please try again later.");
}
