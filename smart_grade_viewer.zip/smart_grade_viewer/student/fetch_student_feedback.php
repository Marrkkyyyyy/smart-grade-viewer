<?php
include "../connect.php";

if (isset($_POST['studentID']) && isset($_POST['teacherClassID'])) {

    $studentID = filterRequest("studentID");
    $teacherClassID = filterRequest("teacherClassID");
    $allData = array();
    $allData['status'] = "success";

    $feedback = getAllData("viewfeedback", "studentID = $studentID && teacherClassID = $teacherClassID", null, false);
    $allData['viewfeedback'] = $feedback;

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}
