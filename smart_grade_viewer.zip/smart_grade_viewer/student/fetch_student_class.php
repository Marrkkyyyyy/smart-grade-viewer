<?php
include "../connect.php";

if(isset($_POST['studentID'])){

    $studentID = filterRequest("studentID");
    $isArchived = 0;
    $allData = array();
    $allData['status'] = "success";
    $class = getAllData("viewstudentclass", "studentID = $studentID AND isArchived = $isArchived", null, false);
    
    $allData['viewstudentclass'] = $class;

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}

?>
