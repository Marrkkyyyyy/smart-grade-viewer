<?php
include "../connect.php";

if (isset($_POST['classID']) && isset($_POST['studentID']) && isset($_POST['teacherClassID'])) {

    $classID = filterRequest("classID");
    $studentID = filterRequest("studentID");
    $teacherClassID = filterRequest("teacherClassID");
    $allData = array();
    $allData['status'] = "success";
    $students = getAllData("viewstudentclass", "classID = $classID", null, false);

    $studentDataStmt = $con->prepare("SELECT grade FROM viewstudentclass WHERE classID = :classID AND studentID = :studentID");
    $studentDataStmt->bindParam(':classID', $classID, PDO::PARAM_STR);
    $studentDataStmt->bindParam(':studentID', $studentID, PDO::PARAM_STR);
    $studentDataStmt->execute();
    $studentData = $studentDataStmt->fetch(PDO::FETCH_ASSOC);

    $evaluationDataStmt = $con->prepare("SELECT * FROM evaluation WHERE studentID = :studentID AND teacherClassID = :teacherClassID");
    $evaluationDataStmt->bindParam(':studentID', $studentID, PDO::PARAM_STR);
    $evaluationDataStmt->bindParam(':teacherClassID', $teacherClassID, PDO::PARAM_STR);
    $evaluationDataStmt->execute();
    $evaluationData = $evaluationDataStmt->fetch(PDO::FETCH_ASSOC);

    $allData['studentGrade'] = $studentData['grade'];
    $allData['viewstudentclass'] = $students;
    $allData['evaluationID'] = $evaluationData['evaluationID'];

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}
