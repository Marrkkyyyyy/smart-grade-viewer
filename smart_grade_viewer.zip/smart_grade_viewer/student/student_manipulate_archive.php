<?php
include "../connect.php";

if(isset($_POST['classroomID']) && isset($_POST['isArchived'])){

    $classroomID = filterRequest("classroomID");
    $isArchived = filterRequest("isArchived");

    $data = array(
        "isArchived" => $isArchived
    );

    $res = updateData("classroom", $data, "classroomID = $classroomID", null);

    if($res){
        printSuccess();
    }else{
        printFailure("Something went wrong. Please try again later");
    }
    
    
}else{
    printFailure("Please send parameters");
}

?>
