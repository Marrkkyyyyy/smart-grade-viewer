<?php
include "../connect.php";

if(isset($_POST['studentID']) && isset($_POST['teacherClassID']) && isset($_POST['senderID']) && isset($_POST['message'])){
    date_default_timezone_set('Asia/Manila');     
    $currentTime = date('Y-m-d H:i:s');
    $studentID = filterRequest("studentID");
    $teacherClassID = filterRequest("teacherClassID");
    $senderID = filterRequest("senderID");
    $message = filterRequest("message");
    
    $data = array(
        "studentID" => $studentID,
        "teacherClassID" => $teacherClassID,
        "senderID" => $senderID,
        "message" => $message,
        "dateCreated" => $currentTime
    );
    
    $res = insertData("feedback", $data, null);
    if($res){
        printSuccess();
    }else{
        printFailure("Something went wrong. Please try again later.");
    }
}else{
    printFailure("Please send parameters");
}

?>
