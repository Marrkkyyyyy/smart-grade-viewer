<?php
include "../connect.php";

if(isset($_POST['studentID'])){

    $studentID = filterRequest("studentID");
    $isArchived = 1;
    $allData = array();
    $groupedCart = array();
    $allData['status'] = "success";

    $classes = getAllData("viewstudentclass", "studentID = $studentID AND isArchived = $isArchived", null, false);
    
    if (!empty($classes)) {
        foreach ($classes as $item) {
            $year = date("Y", strtotime($item['date_created']));
            if (!array_key_exists($year, $groupedCart)) {
                $class = array(
                    'year' => $year, 
                    'studentID' => $item['studentID'], 
                    'isArchived' => $item['isArchived'], 
                    'studentFirstName' => $item['studentFirstName'], 
                    'studentLastName' => $item['studentLastName'], 
                    'studentEmailAddress' => $item['studentEmailAddress'], 
                    'teacherProfile' => $item['teacherProfile'], 
                    'class' => array()
                );
                $groupedCart[$year] = $class;
            }
            $item['date_created'] = date("Y-m-d H:i:s", strtotime($item['date_created']));
            $classItem = array_diff_key($item, $class);
            $groupedCart[$year]['class'][] = $classItem;
        }
    }

    $allData['viewarchivestudent'] = empty($groupedCart) ? [] :  array_values($groupedCart);

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}
?>
