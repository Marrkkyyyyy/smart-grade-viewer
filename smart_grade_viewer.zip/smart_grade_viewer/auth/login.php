<?php
include "../connect.php";

if (isset($_POST['emailAddress']) && isset($_POST['password'])) {
    $emailAddress = filterRequest("emailAddress");
    $password = $_POST["password"];

    $stmtStudent = $con->prepare("SELECT * FROM student WHERE emailAddress = :email");
    $stmtTeacher = $con->prepare("SELECT * FROM teacher WHERE emailAddress = :email");
    $stmtAdmin = $con->prepare("SELECT * FROM admin WHERE emailAddress = :email");

    $stmtStudent->bindParam(':email', $emailAddress, PDO::PARAM_STR);
    $stmtTeacher->bindParam(':email', $emailAddress, PDO::PARAM_STR);
    $stmtAdmin->bindParam(':email', $emailAddress, PDO::PARAM_STR);

    $stmtStudent->execute();
    $stmtTeacher->execute();
    $stmtAdmin->execute();

    $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
    $teacher = $stmtTeacher->fetch(PDO::FETCH_ASSOC);
    $admin = $stmtAdmin->fetch(PDO::FETCH_ASSOC);

    
    if ($student && password_verify($password, $student['password'])) {
        echo json_encode(array(
            "status" => "success",
            "userType" => "student",
            "userData" => $student,
          ));
    } elseif ($teacher && password_verify($password, $teacher['password'])) {
        echo json_encode(array(
            "status" => "success",
            "userType" => "teacher",
            "userData" => $teacher,
          ));
    } elseif ($admin && password_verify($password, $admin['password'])) {
        echo json_encode(array(
            "status" => "success",
            "userType" => "admin",
            "userData" => $admin,
          ));
    } else {
        printFailure("Invalid username or password");
    }
} else {
    printFailure("Please send parameters");
}
?>
