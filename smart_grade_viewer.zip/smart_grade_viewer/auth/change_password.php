<?php
include "../connect.php";

if (isset($_POST['emailAddress']) && isset($_POST['currentPassword']) && isset($_POST['newPassword'])) {
    $emailAddress = filterRequest("emailAddress");
    $currentPassword = $_POST["currentPassword"];
    $newPassword = $_POST["newPassword"];

    $stmtStudent = $con->prepare("SELECT * FROM student WHERE emailAddress = :email");
    $stmtTeacher = $con->prepare("SELECT * FROM teacher WHERE emailAddress = :email");
    $stmtAdmin = $con->prepare("SELECT * FROM admin WHERE emailAddress = :email");

    $stmtStudent->bindParam(':email', $emailAddress, PDO::PARAM_STR);
    $stmtTeacher->bindParam(':email', $emailAddress, PDO::PARAM_STR);
    $stmtAdmin->bindParam(':email', $emailAddress, PDO::PARAM_STR);

    $stmtStudent->execute();
    $stmtTeacher->execute();
    $stmtAdmin->execute();

    $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
    $teacher = $stmtTeacher->fetch(PDO::FETCH_ASSOC);
    $admin = $stmtAdmin->fetch(PDO::FETCH_ASSOC);

    if ($student && password_verify($currentPassword, $student['password'])) {
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $con->prepare("UPDATE student SET password = :newPassword WHERE emailAddress = :email");
        $updateStmt->bindParam(':newPassword', $hashedNewPassword, PDO::PARAM_STR);
        $updateStmt->bindParam(':email', $emailAddress, PDO::PARAM_STR);
        $updateStmt->execute();

        echo json_encode(array(
            "status" => "success",
            "message" => "Password updated successfully",
        ));
    } elseif ($teacher && password_verify($currentPassword, $teacher['password'])) {
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $con->prepare("UPDATE teacher SET password = :newPassword WHERE emailAddress = :email");
        $updateStmt->bindParam(':newPassword', $hashedNewPassword, PDO::PARAM_STR);
        $updateStmt->bindParam(':email', $emailAddress, PDO::PARAM_STR);
        $updateStmt->execute();

        echo json_encode(array(
            "status" => "success",
            "message" => "Password updated successfully",
        ));
    } elseif ($admin && password_verify($currentPassword, $admin['password'])) {
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $con->prepare("UPDATE admin SET password = :newPassword WHERE emailAddress = :email");
        $updateStmt->bindParam(':newPassword', $hashedNewPassword, PDO::PARAM_STR);
        $updateStmt->bindParam(':email', $emailAddress, PDO::PARAM_STR);
        $updateStmt->execute();

        echo json_encode(array(
            "status" => "success",
            "message" => "Password updated successfully",
        ));
    } else {
        echo json_encode(array(
            "status" => "failure",
            "message" => "Invalid current password",
        ));
    }
} else {
    echo json_encode(array(
        "status" => "failure",
        "message" => "Please send all parameters",
    ));
}
?>
