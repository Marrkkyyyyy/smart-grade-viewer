<?php
include "../connect.php";

try {
    $con->beginTransaction();

    if (isset($_POST['userType']) && isset($_POST['emailAddress'])) {
        $userType = filterRequest("userType"); // 0 = admin, 1 = Teacher, 2 = Student
        $emailAddress = filterRequest("emailAddress");
        $stmt = $con->prepare("SELECT emailAddress FROM (
                             SELECT emailAddress FROM student 
                             UNION ALL
                             SELECT emailAddress FROM admin
                             UNION ALL
                             SELECT emailAddress FROM teacher
                             ) AS all_emails
                             WHERE emailAddress = :email");
        $stmt->bindParam(':email', $emailAddress, PDO::PARAM_STR);
        $stmt->execute();
        $count = $stmt->rowCount();

        if ($count > 0) {
            printFailure("Email Address is already taken. Please try another.");
        } else {
            if ($userType == 1) {
                $firstName = filterRequest("firstName");
                $lastName = filterRequest("lastName");
                $emailAddress = filterRequest("emailAddress");
                $password = "Seait123";
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                $isPasswordChanged = "0";
                $profile = null;

                $data = array(
                    "firstName" => $firstName,
                    "lastName" => $lastName,
                    "emailAddress" => $emailAddress,
                    "password" => $hashedPassword,
                    "isPasswordChanged" => $isPasswordChanged,
                    "profile" => $profile
                );

                insertData("teacher", $data, null);

                $userDataStmt = $con->prepare("SELECT * FROM teacher WHERE emailAddress = :emailAddress");
                $userDataStmt->bindParam(':emailAddress', $emailAddress, PDO::PARAM_STR);
                $userDataStmt->execute();
                $userData = $userDataStmt->fetch(PDO::FETCH_ASSOC);

                echo json_encode(array(
                    "status" => "success",
                    "userData" => $userData,
                ));

            } else if ($userType == 2) {
                $schoolID = filterRequest("schoolID");
                $firstName = filterRequest("firstName");
                $lastName = filterRequest("lastName");
                $middleName = filterRequest("middleName");
                $emailAddress = filterRequest("emailAddress");
                $password = $_POST["password"];
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                $profile = null;

                $data = array(
                    "schoolID" => $schoolID,
                    "firstName" => $firstName,
                    "lastName" => $lastName,
                    "middleName" => $middleName,
                    "emailAddress" => $emailAddress,
                    "password" => $hashedPassword,
                    "profile" => $profile
                );
                insertData("student", $data);
            }else if($userType == 0){
                $firstName = filterRequest("firstName");
                $lastName = filterRequest("lastName");
                $emailAddress = filterRequest("emailAddress");
                $password = $_POST['password'];
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

                $data = array(
                    "firstName" => $firstName,
                    "lastName" => $lastName,
                    "emailAddress" => $emailAddress,
                    "password" => $hashedPassword
                );

                insertData("admin", $data, null);

                $userDataStmt = $con->prepare("SELECT * FROM admin WHERE emailAddress = :emailAddress");
                $userDataStmt->bindParam(':emailAddress', $emailAddress, PDO::PARAM_STR);
                $userDataStmt->execute();
                $userData = $userDataStmt->fetch(PDO::FETCH_ASSOC);

                echo json_encode(array(
                    "status" => "success",
                    "userData" => $userData,
                ));
            }
        }
    } else {
        printFailure("Please send parameters");
    }

    $con->commit();

} catch (PDOException $e) {
    $con->rollBack();
    printFailure("Something went wrong. Please try again later");
}
