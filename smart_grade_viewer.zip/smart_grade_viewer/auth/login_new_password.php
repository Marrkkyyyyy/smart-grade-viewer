<?php
include "../connect.php";

if (isset($_POST['teacherID']) && isset($_POST['password'])) {
    try {
        $teacherID = filterRequest("teacherID");
        $password = $_POST["password"];
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        $data = array(
            "password" => $hashedPassword,
            "isPasswordChanged" => "1"
        );

        $res = updateData("teacher", $data, "teacherID = $teacherID", null);
        if($res){
            $stmtTeacher = $con->prepare("SELECT * FROM teacher WHERE teacherID = :teacherID");
            $stmtTeacher->bindParam(':teacherID', $teacherID, PDO::PARAM_STR);
            $stmtTeacher->execute();
            $teacher = $stmtTeacher->fetch(PDO::FETCH_ASSOC);

            echo json_encode(array(
                "status" => "success",
                "userType" => "teacher",
                "userData" => $teacher,
            ));
        } else {
            printFailure("Failed to update password");
        }
    } catch (Exception $e) {
        printFailure("Something went wrong. Please try again later");
    }
} else {
    printFailure("Please send parameters");
}
?>
