-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 02:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_grade_viewer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `emailAddress` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(2, 'Mark Stephen', 'Molina', 'admin@gmail.com', '$2y$10$pNMgKQ/JYjabgBCLeIyjJOVdOttlWkwgMWp.m3SVaLo7vlmJEf4xa');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `classID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(10) NOT NULL,
  `linkCode` varchar(10) NOT NULL,
  `block` int(5) NOT NULL,
  `semester` int(5) NOT NULL,
  `color` varchar(100) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `isArchived` int(11) NOT NULL COMMENT '1 = archived, 0 = not archived'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `classroomID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `teacherClassID` int(11) NOT NULL,
  `isArchived` int(11) NOT NULL COMMENT '0 = not archived, 1 = archived',
  `grade` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE `evaluation` (
  `evaluationID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `teacherClassID` int(11) NOT NULL,
  `evaluation` varchar(255) NOT NULL,
  `comment` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `teacherClassID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `dateCreated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `requestID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `teacherClassID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentID` int(11) NOT NULL,
  `schoolID` varchar(15) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `middleName` varchar(100) DEFAULT NULL,
  `emailAddress` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacherID` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `emailAddress` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `isPasswordChanged` int(11) NOT NULL COMMENT '1 = changed, 0 = not changed',
  `profile` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacherclass`
--

CREATE TABLE `teacherclass` (
  `teacherClassID` int(11) NOT NULL,
  `teacherID` int(11) NOT NULL,
  `classID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewclass`
-- (See below for the actual view)
--
CREATE TABLE `viewclass` (
`teacherClassID` int(11)
,`teacherID` int(11)
,`classID` int(11)
,`firstName` varchar(100)
,`lastName` varchar(100)
,`profile` varchar(255)
,`name` varchar(50)
,`code` varchar(10)
,`linkCode` varchar(10)
,`block` int(5)
,`semester` int(5)
,`color` varchar(100)
,`date_created` datetime
,`isArchived` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewfeedback`
-- (See below for the actual view)
--
CREATE TABLE `viewfeedback` (
`feedbackID` int(11)
,`studentID` int(11)
,`teacherClassID` int(11)
,`senderID` int(11)
,`message` varchar(200)
,`dateCreated` datetime
,`teacherID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewrequest`
-- (See below for the actual view)
--
CREATE TABLE `viewrequest` (
`requestID` int(11)
,`studentID` int(11)
,`teacherClassID` int(11)
,`teacherID` int(11)
,`classID` int(11)
,`schoolID` varchar(15)
,`firstName` varchar(100)
,`lastName` varchar(100)
,`middleName` varchar(100)
,`emailAddress` varchar(100)
,`profile` varchar(255)
,`name` varchar(50)
,`code` varchar(10)
,`linkCode` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewstudentclass`
-- (See below for the actual view)
--
CREATE TABLE `viewstudentclass` (
`classroomID` int(11)
,`studentID` int(11)
,`teacherClassID` int(11)
,`isArchived` int(11)
,`grade` varchar(10)
,`studentFirstName` varchar(100)
,`studentLastName` varchar(100)
,`studentMiddleName` varchar(100)
,`studentEmailAddress` varchar(100)
,`firstName` varchar(100)
,`lastName` varchar(100)
,`teacherProfile` varchar(255)
,`studentProfile` varchar(255)
,`teacherID` int(11)
,`classID` int(11)
,`name` varchar(50)
,`code` varchar(10)
,`linkCode` varchar(10)
,`block` int(5)
,`semester` int(5)
,`color` varchar(100)
,`date_created` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `viewteacherstudent`
-- (See below for the actual view)
--
CREATE TABLE `viewteacherstudent` (
`classroomID` int(11)
,`studentID` int(11)
,`teacherClassID` int(11)
,`grade` varchar(10)
,`classID` int(11)
,`teacherID` int(11)
,`firstName` varchar(100)
,`lastName` varchar(100)
,`profile` varchar(255)
,`emailAddress` varchar(100)
,`feedbackID` int(11)
,`senderID` int(11)
,`message` varchar(200)
,`dateCreated` datetime
);

-- --------------------------------------------------------

--
-- Structure for view `viewclass`
--
DROP TABLE IF EXISTS `viewclass`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewclass`  AS SELECT `teacherclass`.`teacherClassID` AS `teacherClassID`, `teacherclass`.`teacherID` AS `teacherID`, `teacherclass`.`classID` AS `classID`, `teacher`.`firstName` AS `firstName`, `teacher`.`lastName` AS `lastName`, `teacher`.`profile` AS `profile`, `class`.`name` AS `name`, `class`.`code` AS `code`, `class`.`linkCode` AS `linkCode`, `class`.`block` AS `block`, `class`.`semester` AS `semester`, `class`.`color` AS `color`, `class`.`date_created` AS `date_created`, `class`.`isArchived` AS `isArchived` FROM ((`teacherclass` left join `teacher` on(`teacher`.`teacherID` = `teacherclass`.`teacherID`)) left join `class` on(`class`.`classID` = `teacherclass`.`classID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `viewfeedback`
--
DROP TABLE IF EXISTS `viewfeedback`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewfeedback`  AS SELECT `feedback`.`feedbackID` AS `feedbackID`, `feedback`.`studentID` AS `studentID`, `feedback`.`teacherClassID` AS `teacherClassID`, `feedback`.`senderID` AS `senderID`, `feedback`.`message` AS `message`, `feedback`.`dateCreated` AS `dateCreated`, `teacherclass`.`teacherID` AS `teacherID` FROM (`feedback` left join `teacherclass` on(`teacherclass`.`teacherClassID` = `feedback`.`teacherClassID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `viewrequest`
--
DROP TABLE IF EXISTS `viewrequest`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewrequest`  AS SELECT `request`.`requestID` AS `requestID`, `request`.`studentID` AS `studentID`, `request`.`teacherClassID` AS `teacherClassID`, `teacher`.`teacherID` AS `teacherID`, `class`.`classID` AS `classID`, `student`.`schoolID` AS `schoolID`, `student`.`firstName` AS `firstName`, `student`.`lastName` AS `lastName`, `student`.`middleName` AS `middleName`, `student`.`emailAddress` AS `emailAddress`, `student`.`profile` AS `profile`, `class`.`name` AS `name`, `class`.`code` AS `code`, `class`.`linkCode` AS `linkCode` FROM ((((`request` left join `student` on(`request`.`studentID` = `student`.`studentID`)) left join `teacherclass` on(`request`.`teacherClassID` = `teacherclass`.`teacherClassID`)) left join `class` on(`teacherclass`.`classID` = `class`.`classID`)) left join `teacher` on(`teacherclass`.`teacherID` = `teacher`.`teacherID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `viewstudentclass`
--
DROP TABLE IF EXISTS `viewstudentclass`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewstudentclass`  AS SELECT `classroom`.`classroomID` AS `classroomID`, `classroom`.`studentID` AS `studentID`, `classroom`.`teacherClassID` AS `teacherClassID`, `classroom`.`isArchived` AS `isArchived`, `classroom`.`grade` AS `grade`, `student`.`firstName` AS `studentFirstName`, `student`.`lastName` AS `studentLastName`, `student`.`middleName` AS `studentMiddleName`, `student`.`emailAddress` AS `studentEmailAddress`, `teacher`.`firstName` AS `firstName`, `teacher`.`lastName` AS `lastName`, `teacher`.`profile` AS `teacherProfile`, `student`.`profile` AS `studentProfile`, `teacherclass`.`teacherID` AS `teacherID`, `teacherclass`.`classID` AS `classID`, `class`.`name` AS `name`, `class`.`code` AS `code`, `class`.`linkCode` AS `linkCode`, `class`.`block` AS `block`, `class`.`semester` AS `semester`, `class`.`color` AS `color`, `class`.`date_created` AS `date_created` FROM ((((`classroom` join `teacherclass` on(`classroom`.`teacherClassID` = `teacherclass`.`teacherClassID`)) left join `teacher` on(`teacherclass`.`teacherID` = `teacher`.`teacherID`)) left join `class` on(`teacherclass`.`classID` = `class`.`classID`)) left join `student` on(`classroom`.`studentID` = `student`.`studentID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `viewteacherstudent`
--
DROP TABLE IF EXISTS `viewteacherstudent`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viewteacherstudent`  AS SELECT `classroom`.`classroomID` AS `classroomID`, `classroom`.`studentID` AS `studentID`, `classroom`.`teacherClassID` AS `teacherClassID`, `classroom`.`grade` AS `grade`, `teacherclass`.`classID` AS `classID`, `teacherclass`.`teacherID` AS `teacherID`, `student`.`firstName` AS `firstName`, `student`.`lastName` AS `lastName`, `student`.`profile` AS `profile`, `student`.`emailAddress` AS `emailAddress`, `feedback`.`feedbackID` AS `feedbackID`, `feedback`.`senderID` AS `senderID`, `feedback`.`message` AS `message`, `feedback`.`dateCreated` AS `dateCreated` FROM (((`classroom` left join `student` on(`classroom`.`studentID` = `student`.`studentID`)) join `teacherclass` on(`classroom`.`teacherClassID` = `teacherclass`.`teacherClassID`)) left join `feedback` on(`classroom`.`teacherClassID` = `feedback`.`teacherClassID` and `classroom`.`studentID` = `feedback`.`studentID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`classID`);

--
-- Indexes for table `classroom`
--
ALTER TABLE `classroom`
  ADD PRIMARY KEY (`classroomID`),
  ADD KEY `teacherClassID` (`teacherClassID`),
  ADD KEY `studentID` (`studentID`);

--
-- Indexes for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`evaluationID`),
  ADD KEY `teacherClassID` (`teacherClassID`),
  ADD KEY `studentID` (`studentID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackID`),
  ADD KEY `teacherClassID` (`teacherClassID`),
  ADD KEY `studentID` (`studentID`),
  ADD KEY `senderID` (`senderID`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`requestID`),
  ADD KEY `teacherClassID` (`teacherClassID`),
  ADD KEY `studentID` (`studentID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacherID`);

--
-- Indexes for table `teacherclass`
--
ALTER TABLE `teacherclass`
  ADD PRIMARY KEY (`teacherClassID`),
  ADD KEY `classID` (`classID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `classID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `classroom`
--
ALTER TABLE `classroom`
  MODIFY `classroomID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `evaluationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `requestID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacherID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `teacherclass`
--
ALTER TABLE `teacherclass`
  MODIFY `teacherClassID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
