<?php
include "../connect.php";

try {
    $con->beginTransaction();

    if (isset($_POST['teacherID']) && isset($_POST['firstName']) && isset($_POST['lastName'])) {
        $teacherID = filterRequest("teacherID");
        $firstName = filterRequest("firstName");
        $lastName = filterRequest("lastName");
        $imageURL = null;

        if (isset($_FILES['image'])) {
            $image = $_FILES['image'];

            $user_folder = "../auth/user_profile/";
            $original_file_name1 = basename($image['name']);
            $original_file_name = preg_replace('/[\s,]+/', '_', $original_file_name1);
            $target_file = $user_folder . $original_file_name;

            if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                throw new Exception('Failed to upload image: ' . $_FILES['image']['error']);
            } else {
                $imageURL = $original_file_name;
            }
        }

        $data = array(
            "firstName" => $firstName,
            "lastName" => $lastName,
            "profile" => $imageURL
        );

        $res = updateData("teacher", $data, "teacherID = $teacherID", null);
        if($res){
            printSuccess();
        }else{
            printFailure("Something went wrong. Please try again later.");
        }
    
    } else {
        printFailure("Please send parameters");
    }

    $con->commit();
} catch (PDOException $e) {
    $con->rollBack();
    printFailure("Something went wrong. Please try again later.");
}
