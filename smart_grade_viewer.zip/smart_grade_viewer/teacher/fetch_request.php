<?php
include "../connect.php";

if(isset($_POST['classID'])){

    $classID = filterRequest("classID");
    $allData = array();
    $groupedCart = array();
    $allData['status'] = "success";

    $requests = getAllData("viewrequest", "classID = $classID", null, false);
    
    $allData['viewrequest'] = $requests;

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}

?>
