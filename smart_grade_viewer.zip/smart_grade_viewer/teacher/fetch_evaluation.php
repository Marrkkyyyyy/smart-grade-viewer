<?php
include "../connect.php";

if(isset($_POST['teacherClassID'])){

    $teacherClassID = filterRequest("teacherClassID");
    $allData = array();
    $allData['status'] = "success";

    $evaluationData = getAllData("evaluation", "teacherClassID = $teacherClassID", null, false);
    
    $allData['evaluationData'] = $evaluationData;

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}

?>
