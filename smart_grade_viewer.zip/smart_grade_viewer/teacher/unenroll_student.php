<?php
include "../connect.php";

if (isset($_POST['classroomID']) && isset($_POST['studentID'])  && isset($_POST['teacherClassID'])) {
    try {
        $classroomID = filterRequest("classroomID");
        $studentID = filterRequest("studentID");
        $teacherClassID = filterRequest("teacherClassID");

        $con->beginTransaction();

        $stmtClassroom = $con->prepare("DELETE FROM classroom WHERE classroomID = :classroomID");
        $stmtClassroom->bindParam(':classroomID', $classroomID, PDO::PARAM_STR);
        $stmtClassroom->execute();

        $stmtFeedback = $con->prepare("DELETE FROM feedback WHERE studentID = :studentID AND teacherClassID = :teacherClassID");
        $stmtFeedback->bindParam(':studentID', $studentID, PDO::PARAM_STR);
        $stmtFeedback->bindParam(':teacherClassID', $teacherClassID, PDO::PARAM_STR);
        $stmtFeedback->execute();

        $con->commit();
        
        printSuccess();
    } catch (PDOException $e) {
        $con->rollBack();
        printFailure("Something went wrong. Please try again later.");
    }
} else {
    printFailure("Please send parameters");
}
?>
