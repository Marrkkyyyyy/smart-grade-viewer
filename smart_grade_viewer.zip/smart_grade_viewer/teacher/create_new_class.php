<?php
include "../connect.php";

try {
    if (isset($_POST['teacherID']) && isset($_POST['name']) && isset($_POST['code']) && isset($_POST['block']) && isset($_POST['semester']) && isset($_POST['color'])) {
        date_default_timezone_set('Asia/Manila');
        $currentTime = date('Y-m-d H:i:s');
        $teacherID = filterRequest("teacherID");
        $name = filterRequest("name");
        $code = filterRequest("code");
        $block = filterRequest("block");
        $semester = filterRequest("semester");
        $color = filterRequest("color");

        do {
            $linkCode = generateRandomCode();
            $stmt = $con->prepare("SELECT * FROM class WHERE linkCode = :linkCode");
            $stmt->bindParam(':linkCode', $linkCode, PDO::PARAM_STR);
            $stmt->execute();
            $linkCount = $stmt->rowCount();
        } while ($linkCount > 0); 

        $stmtClass = $con->prepare("SELECT * FROM class WHERE name = :name AND code = :code AND block = :block AND semester = :semester AND YEAR(date_created) = YEAR(CURDATE())");
        $stmtClass->bindParam(':name', $name, PDO::PARAM_STR);
        $stmtClass->bindParam(':code', $code, PDO::PARAM_STR);
        $stmtClass->bindParam(':block', $block, PDO::PARAM_STR);
        $stmtClass->bindParam(':semester', $semester, PDO::PARAM_STR);
        $stmtClass->execute();
        $classCount = $stmtClass->rowCount();   

        if($classCount > 0){
            printFailure("Duplicate class found. Verify class details.");
        } else {
            $data = array(
                "name" => $name,
                "code" => $code,
                "linkCode" => $linkCode,
                "block" => $block,
                "semester" => $semester,
                "color" => $color,
                "date_created" => $currentTime,
                "isArchived" => "0",
            );

            insertData("class", $data, null);

            $classDataStmt = $con->prepare("SELECT * FROM class WHERE name = :name AND code = :code AND block = :block AND semester = :semester AND YEAR(date_created) = YEAR(CURDATE())");
            $classDataStmt->bindParam(':name', $name, PDO::PARAM_STR);
            $classDataStmt->bindParam(':code', $code, PDO::PARAM_STR);
            $classDataStmt->bindParam(':block', $block, PDO::PARAM_STR);
            $classDataStmt->bindParam(':semester', $semester, PDO::PARAM_STR);
            $classDataStmt->execute();
            $classData = $classDataStmt->fetch(PDO::FETCH_ASSOC);

            $teacherClassData = array(
                "teacherID" => $teacherID,
                "classID" => $classData['classID'],
            );

            insertData("teacherclass", $teacherClassData, null);
            printSuccess();
        }

    } else {
        printFailure("Please send parameters");
    }
} catch (PDOException $e) {
    printFailure("Something went wrong. Please try again later");
} 
?>
