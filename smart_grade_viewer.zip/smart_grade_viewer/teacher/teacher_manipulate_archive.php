<?php
include "../connect.php";

if(isset($_POST['classID']) && isset($_POST['isArchived'])){

    $classID = filterRequest("classID");
    $isArchived = filterRequest("isArchived");

    $data = array(
        "isArchived" => $isArchived
    );

    $res = updateData("class", $data, "classID = $classID", null);

    if($res){
        printSuccess();
    }else{
        printFailure("Something went wrong. Please try again later");
    }
    
    
}else{
    printFailure("Please send parameters");
}

?>
