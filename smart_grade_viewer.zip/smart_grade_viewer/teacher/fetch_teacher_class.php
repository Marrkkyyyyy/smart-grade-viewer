<?php
include "../connect.php";

if(isset($_POST['teacherID'])){

    $teacherID = filterRequest("teacherID");
    $isArchived = "0";
    $allData = array();
    $allData['status'] = "success";

    $teachers = getAllData("viewclass", "teacherID = $teacherID AND isArchived = $isArchived", null, false);
    
    $allData['viewclass'] = $teachers;

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}

?>
