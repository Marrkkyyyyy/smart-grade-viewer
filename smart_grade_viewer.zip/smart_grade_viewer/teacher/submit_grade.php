<?php
include "../connect.php";

if(isset($_POST['classroomID']) && isset($_POST['grade'])){

    $classroomID = filterRequest("classroomID");
    $grade = filterRequest("grade");
    
    $data = array(
        "grade" => $grade
    );
    
    $res = updateData("classroom", $data, "classroomID = $classroomID", null);
    if($res){
        printSuccess();
    }else{
        printFailure("Something went wrong. Please try again later.");
    }
}else{
    printFailure("Please send parameters");
}

?>
