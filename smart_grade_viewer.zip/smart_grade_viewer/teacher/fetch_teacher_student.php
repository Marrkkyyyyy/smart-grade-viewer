<?php
include "../connect.php";

if(isset($_POST['classID'])){

    $classID = filterRequest("classID");
    $allData = array();
    $groupedCart = array();
    $allData['status'] = "success";

    $students = getAllData("viewteacherstudent", "classID = $classID", null, false);
    
    if (!empty($students)) {
        foreach ($students as $item) {
            $classroomID = $item['classroomID'];
            if (!array_key_exists($classroomID, $groupedCart)) {
                $student = array(
                    'classroomID' => $item['classroomID'], 
                    'studentID' => $item['studentID'], 
                    'teacherClassID' => $item['teacherClassID'], 
                    'grade' => $item['grade'], 
                    'classID' => $item['classID'], 
                    'teacherID' => $item['teacherID'], 
                    'firstName' => $item['firstName'], 
                    'lastName' => $item['lastName'],  
                    'profile' => $item['profile'], 
                    'emailAddress' => $item['emailAddress'],
                    'feedback' => array()
                );
                $groupedCart[$classroomID] = $student;
            }
            $feedbackItem = array_diff_key($item, $student);
            $groupedCart[$classroomID]['feedback'][] = $feedbackItem;
        }
    }

    $allData['viewteacherstudent'] = empty($groupedCart) ? [] :  array_values($groupedCart);



    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}

?>


