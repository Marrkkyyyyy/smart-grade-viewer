<?php
include "../connect.php";

try {
    if (isset($_POST['requestID']) && isset($_POST['studentID'])  && isset($_POST['teacherClassID'])) {
        $requestID = filterRequest("requestID");
        $studentID = filterRequest("studentID");
        $teacherClassID = filterRequest("teacherClassID");
        $res = deleteData("request", "requestID = $requestID", null);

        if ($res) {
            $data = array(
                "studentID" => $studentID,
                "teacherClassID" => $teacherClassID,
                "isArchived" => "0"
            );

            insertData("classroom", $data);
        } else {
            printFailure("Something went wrong. Please try again later.");
        }
    }else{
        printFailure("Please send parameters");
    }
} catch (Exception $e) {
    printFailure("Something went wrong. Please try again later.");
}
?>
