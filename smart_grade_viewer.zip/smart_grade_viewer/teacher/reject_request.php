<?php
include "../connect.php";

if (isset($_POST['requestID'])) {
    $requestID = filterRequest("requestID");
    $res = deleteData("request", "requestID = $requestID", null);
    if ($res) {
        printSuccess();
    } else {
        printFailure("Something went wrong. Please try again later.");
    }
}else{
    printFailure("Please send parameters");
}
