<?php
include "../connect.php";

if(isset($_POST['teacherID'])){

    $teacherID = filterRequest("teacherID");
    $isArchived = 1;
    $allData = array();
    $groupedCart = array();
    $allData['status'] = "success";

    $classes = getAllData("viewclass", "teacherID = $teacherID AND isArchived = $isArchived", null, false);
    
    if (!empty($classes)) {
        foreach ($classes as $item) {
            $year = date("Y", strtotime($item['date_created']));
            if (!array_key_exists($year, $groupedCart)) {
                $class = array(
                    'year' => $year, 
                    'isArchived' => $item['isArchived'], 
                    'class' => array()
                );
                $groupedCart[$year] = $class;
            }
            $item['date_created'] = date("Y-m-d H:i:s", strtotime($item['date_created']));
            $classItem = array_diff_key($item, $class);
            $groupedCart[$year]['class'][] = $classItem;
        }
    }

    $allData['viewclass'] = empty($groupedCart) ? [] :  array_values($groupedCart);

    echo json_encode($allData);
}else{
    printFailure("Please send parameters");
}
?>
