<?php
include "../connect.php";

$allData = array();
$allData['status'] = "success";

$sql = "SELECT teacher.*, teacherclass.teacherClassID 
        FROM teacher 
        LEFT JOIN teacherclass ON teacher.teacherID = teacherClass.teacherID 
        GROUP BY teacher.teacherID";

$stmt = $con->prepare($sql);
$stmt->execute();

$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$allData['teacher'] = $teachers;

echo json_encode($allData);
?>
