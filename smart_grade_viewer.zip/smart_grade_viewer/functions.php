<?php
define("MB", 1048576);

function filterRequest($requestname)
{
  return  htmlspecialchars(strip_tags($_POST[$requestname]));
}

function getAllData($table, $where = null, $values = null, $json = true)
{
    global $con;
    $data = array();

    if ($where === null) {
        $sql = "SELECT * FROM $table";
        $stmt = $con->query($sql);
    } else {
        $sql = "SELECT * FROM $table WHERE $where";
        $stmt = $con->prepare($sql);
        $stmt->execute($values);
    }

    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count = $stmt->rowCount();

    if ($json == true) {
        if ($count > 0) {
            echo json_encode(array("status" => "success", "data" => $data));
        } else {
            echo json_encode(array("status" => "failure"));
        }
    }
    return $data;
}


function getData($table, $where = null, $values = null, $json = true)
{
    global $con;
    $data = array();

    if ($where === null) {
        $sql = "SELECT * FROM $table";
        $stmt = $con->query($sql);
    } else {
        $sql = "SELECT * FROM $table WHERE $where LIMIT 1";
        $stmt = $con->prepare($sql);
        $stmt->execute($values);
    }

    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count = $stmt->rowCount();

    if ($json == true) {
        if ($count > 0) {
            if ($count === 1) {
                echo json_encode(array("status" => "success", "data" => $data[0]));
            } else {
                echo json_encode(array("status" => "success", "data" => $data));
            }
        } else {
            echo json_encode(array("status" => "failure"));
        }
    }
    return $count;
}

function insertData($table, $data, $json = true)
{
    global $con; 
    $fields = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($fields) VALUES ($placeholders)";

    $stmt = $con->prepare($sql);
    
    foreach ($data as $field => $value) {
        $stmt->bindValue(':' . $field, $value);
    }

    if ($stmt->execute()) {
        $count = $stmt->rowCount();
        if ($json == true) {
            echo json_encode(array("status" => "success"));
        }
        return $count;
    } else {
        if ($json == true) {
            echo json_encode(array("status" => "failure"));
        }
        return 0;
    }
}


function insertReturn($table, $data, $json = true)
{
    global $con;
    $fields = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($fields) VALUES ($placeholders)";

    $stmt = $con->prepare($sql);
    
    foreach ($data as $field => $value) {
        $stmt->bindValue(':' . $field, $value);
    }
    if ($stmt->execute()) {
        $count = $stmt->rowCount();
        if ($json == true) {
            return $count > 0;
        }
        return $count;
    } else {
        if ($json == true) {
            return false;
        }
        return 0;
    }
}



function updateReturn($table, $data, $where, $json = true)
{
    global $con;
    $cols = array();

    foreach ($data as $key => $val) {
        $cols[] = "`$key` = :$key";
    }
    $sql = "UPDATE $table SET " . implode(', ', $cols) . " WHERE $where";
    
    $stmt = $con->prepare($sql);
    
    foreach ($data as $key => $val) {
        $stmt->bindValue(":$key", $val);
    }
    if ($stmt->execute()) {
        $count = $stmt->rowCount();
        if ($json == true) {
            return $count > 0;
        }
        return $count;
    } else {
        if ($json == true) {
            return false;
        }
        return 0;
    }
}



function updateData($table, $data, $where, $json = true)
{
    global $con;
    $cols = array();
    foreach ($data as $key => $val) {
        $cols[] = "`$key` = :$key";
    }
    
    $sql = "UPDATE $table SET " . implode(', ', $cols) . " WHERE $where";
    
    $stmt = $con->prepare($sql);
    
    foreach ($data as $key => $val) {
        $stmt->bindValue(":$key", $val);
    }
    if ($stmt->execute()) {
        $count = $stmt->rowCount();
        if ($json == true) {
            if ($count > 0) {
                echo json_encode(array("status" => "success"));
            } else {
                echo json_encode(array("status" => "failure"));
            }
        }
        return $count;
    } else {
        if ($json == true) {
            echo json_encode(array("status" => "failure"));
        }
        return 0;
    }
}


function deleteData($table, $where, $json = true)
{
    global $con;

    $where = htmlspecialchars($where, ENT_QUOTES, 'UTF-8');

    $stmt = $con->prepare("DELETE FROM $table WHERE $where");
    if ($stmt->execute()) {
        $count = $stmt->rowCount();
        if ($json == true) {
            if ($count > 0) {
                echo json_encode(array("status" => "success"));
            } else {
                echo json_encode(array("status" => "failure"));
            }
        }
        return $count;
    } else {
        if ($json == true) {
            echo json_encode(array("status" => "failure", "error" => $stmt->errorInfo()));
        }
        return 0;
    }
}



function imageUpload($imageRequest)
{
  global $msgError;
  $imagename  = rand(1000, 10000) . $_FILES[$imageRequest]['name'];
  $imagetmp   = $_FILES[$imageRequest]['tmp_name'];
  $imagesize  = $_FILES[$imageRequest]['size'];
  $allowExt   = array("jpg", "png", "gif", "mp3", "pdf");
  $strToArray = explode(".", $imagename);
  $ext        = end($strToArray);
  $ext        = strtolower($ext);

  if (!empty($imagename) && !in_array($ext, $allowExt)) {
    $msgError = "EXT";
  }
  if ($imagesize > 2 * MB) {
    $msgError = "size";
  }
  if (empty($msgError)) {
    move_uploaded_file($imagetmp,  "../upload/" . $imagename);
    return $imagename;
  } else {
    return "fail";
  }
}

function compressAndSaveImage($sourcePath, $targetPath, $quality) {
    $info = getimagesize($sourcePath);
    if ($info['mime'] == 'image/jpeg') {
        $image = imagecreatefromjpeg($sourcePath);
    } elseif ($info['mime'] == 'image/png') {
        $image = imagecreatefrompng($sourcePath);
    } else {
        // Unsupported image type
        return false;
    }

    // Compress and save the image
    if (imagejpeg($image, $targetPath, $quality)) {
        imagedestroy($image);
        return true;
    } else {
        // Failed to compress or save the image
        return false;
    }
}




function deleteFile($dir, $imagename)
{
    if (file_exists($dir . "/" . $imagename)) {
        unlink($dir . "/" . $imagename);
    }
}

function checkAuthenticate()
{
    if (isset($_SERVER['PHP_AUTH_USER'])  && isset($_SERVER['PHP_AUTH_PW'])) {
        if ($_SERVER['PHP_AUTH_USER'] != "wael" ||  $_SERVER['PHP_AUTH_PW'] != "wael12345") {
            header('WWW-Authenticate: Basic realm="My Realm"');
            header('HTTP/1.0 401 Unauthorized');
            echo 'Page Not Found';
            exit;
        }
    } else {
        exit;
    }

}

function printFailure($message = "none"){
    echo json_encode(array("status" => "failure", "message" => $message));
}

function printSuccess(){
    echo json_encode(array("status" => "success"));
}


function generateRandomCode($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $randomString;
}